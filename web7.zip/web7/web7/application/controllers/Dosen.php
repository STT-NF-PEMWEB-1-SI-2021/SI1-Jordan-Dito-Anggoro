<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Dosen extends CI_Controller {

    public function index(){
        $this->load->model('Dosen_model', 'dsn1');
        $this->dsn1->id=1;
        $this->dsn1->nama='Sumardi';
        $this->dsn1->nidn='01101209';
        $this->dsn1->pendidikan='S2';

        $this->load->model('Dosen_model', 'dsn2');
        $this->dsn2->id=2;
        $this->dsn2->nama='Saipullah';
        $this->dsn2->nidn='011012010';
        $this->dsn2->pendidikan='S2';

        $this->load->model('Dosen_model', 'dsn3');
        $this->dsn3->id=3;
        $this->dsn3->nama='Joko purwanto';
        $this->dsn3->nidn='011012014';
        $this->dsn3->pendidikan='S2';

        $list_dsn = [$this->dsn1, $this->dsn2, $this->dsn3];
        $data1['list_dsn'] = $list_dsn;

        $this->load->view('Dosen/index', $data1);

    }
}

?>