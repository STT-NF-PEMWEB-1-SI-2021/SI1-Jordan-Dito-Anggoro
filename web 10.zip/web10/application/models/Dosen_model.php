<?php
class Dosen_model extends CI_Model {
    public $nidn;
    public $nama;
    public $gender;
    public $tmp_lahir;
    public $tgl_lahir;
    public $pendidikan_akhir;
    public $prodi_kode;

    private $obj = "dosen";

    public function getAll(){
        $query = $this->db->get($this->obj);
        return $query->result();
    }

    public function findById($id){
        $this->db->where("nidn",$id);
        $query = $this->db->get($this->obj);
        return $query->row();
    }

   
   

}

?>