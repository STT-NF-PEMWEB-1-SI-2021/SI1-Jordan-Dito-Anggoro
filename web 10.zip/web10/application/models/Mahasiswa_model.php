<?php
class Mahasiswa_model extends CI_Model {

    public $id;
    public $nama;
    public $nim;
    public $gender;
    public $tmp_lahir;
    public $tgl_lahir;
    public $prodi_kode;
    public $ipk;

    public function predikat(){
        $predikat = ($this->ipk >= 3.75)?"Cumlaude" : "Baik";
       return $predikat;
    }
    
    private $table = "mahasiswa";

    public function getAll(){
        //SELECT * FROM mahasiswa
        $query = $this->db->get($this->table);
        return $query->result();
    }

    public function findById($id){
        $this->db->where("nim",$id);
        $query = $this->db->get($this->table);
        return $query->row();
    }

   
}
?>