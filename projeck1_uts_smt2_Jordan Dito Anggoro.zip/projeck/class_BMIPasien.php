<?php
    class BMIPasien{
        public $BMI;
        public $tanggal;
        public $pasien;
    }
    function __construct($BMI, $tanggal, $pasien){
        $this->BMI;
        $this->tanggal;
        $this->pasien;
    }

?>